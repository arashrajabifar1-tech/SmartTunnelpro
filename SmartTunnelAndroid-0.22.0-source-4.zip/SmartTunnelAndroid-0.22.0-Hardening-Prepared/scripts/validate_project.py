#!/usr/bin/env python3
"""Offline static checks for Smart Tunnel. Does not replace Android build/device tests."""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "app/src/main/assets/index.html"
GRADLE = ROOT / "app/build.gradle.kts"
WORKFLOW = ROOT / ".github/workflows/android-apk.yml"


def require(ok: bool, message: str) -> None:
    if not ok:
        raise SystemExit(f"FAIL: {message}")
    print(f"PASS: {message}")


def main() -> int:
    require(HTML.is_file(), "Android WebView HTML asset exists")
    html = HTML.read_text(encoding="utf-8")
    gradle = GRADLE.read_text(encoding="utf-8")
    workflow = WORKFLOW.read_text(encoding="utf-8")

    require("Smart Tunnel v0.22.0" in html, "HTML version is 0.22.0")
    require('versionName = "0.22.0"' in gradle and "versionCode = 220" in gradle,
            "Android app version is 0.22.0 / code 220")
    require('com.github.singbox-android:libbox:1.14.3' in gradle,
            "libbox dependency is pinned to 1.14.3")
    require("SmartTunnel-0.22.0-debug-apk" in workflow,
            "CI artifact name matches current version")
    require("CommandServer(this, this)" in (ROOT / "app/src/main/java/com/smarttunnel/app/vpn/VpnEngine.kt").read_text(encoding="utf-8"),
            "native engine creates a sing-box CommandServer")

    xml_files = sorted((ROOT / "app/src/main").rglob("*.xml"))
    require(bool(xml_files), "Android XML resources were found")
    for path in xml_files:
        ET.parse(path)
    print(f"PASS: parsed {len(xml_files)} Android XML files")

    node = shutil.which("node")
    require(node is not None, "Node.js is installed for JavaScript syntax checks")
    scripts = re.findall(r"<script\b[^>]*>(.*?)</script\s*>", html, flags=re.I | re.S)
    require(bool(scripts), "inline JavaScript blocks were found")
    with tempfile.TemporaryDirectory(prefix="smarttunnel-js-") as temp:
        for i, source in enumerate(scripts, start=1):
            js = Path(temp) / f"script-{i}.js"
            js.write_text(source, encoding="utf-8")
            result = subprocess.run([node, "--check", str(js)], capture_output=True, text=True)
            if result.returncode:
                print(result.stdout, file=sys.stderr)
                print(result.stderr, file=sys.stderr)
                raise SystemExit(f"FAIL: JavaScript syntax block {i}")
    print(f"PASS: node --check on {len(scripts)} JavaScript blocks")

    start = html.find("async function classifyNetwork()")
    end = html.find("function applyProfileFor(type,c)", start)
    require(start >= 0 and end > start, "network classifier source was found")
    classifier = html[start:end]
    require("getNetworkInfo" in classifier and "getWifiInfo" in classifier,
            "classifier reads Android network capabilities and Wi-Fi hint")
    require("probe(" not in classifier and "fetch(" not in classifier,
            "network classification makes no repeated external HTTP probes")
    require("mtu:9000" not in html.lower(), "no generic MTU=9000 preset remains")
    require("domain_suffix:['.ir']" in html or 'domain_suffix:[".ir"]' in html,
            "normal/emergency profiles include explicit .ir routing")
    require("stEmergencyPanel" in html and "PBKDF2" in html and "AES-GCM" in html,
            "encrypted offline emergency-kit code is present")
    require("Speed Booster Pack loaded" in html, "Speed Booster UI layer is present")
    require("speedTestThroughTunnel" in html and "speedTestThroughTunnel" in (ROOT / "app/src/main/java/com/smarttunnel/app/bridge/SmartTunnelBridge.kt").read_text(encoding="utf-8"),
            "real native throughput benchmark bridge is wired")
    require("cancelSpeedTest" in (ROOT / "app/src/main/java/com/smarttunnel/app/bridge/SmartTunnelBridge.kt").read_text(encoding="utf-8"),
            "native speed tests support cancellation")
    require("enabled:false" in html and "community configs" in html.lower(),
            "public-source configs are imported disabled, not auto-connected")
    bridge = (ROOT / "app/src/main/java/com/smarttunnel/app/bridge/SmartTunnelBridge.kt").read_text(encoding="utf-8")
    activity = (ROOT / "app/src/main/java/com/smarttunnel/app/ui/MainActivity.kt").read_text(encoding="utf-8")
    require('"shadowtls" -> "shadowtls"' in bridge and '"shadowtls")' in bridge and 'shadowtls)://' in bridge,
            "native subscription parser supports ShadowTLS")
    require('parsed.host.equals("www.gstatic.com", true)' in bridge and 'parsed.path == "/generate_204"' in bridge,
            "native tunnel probe is restricted to a fixed HTTPS endpoint")
    require("decodeURIComponent(escape(atob(" in bridge,
            "deep-link payload is encoded before JavaScript evaluation")
    require("allowFileAccessFromFileURLs = false" in activity and "allowUniversalAccessFromFileURLs = false" in activity,
            "WebView file-origin access is restricted")
    require("Vazirmatn-font-face.css" not in html,
            "the offline UI does not auto-contact a font CDN")
    require("lastExitIpFetchedAt" in bridge and "ByteArrayOutputStream" in bridge,
            "exit-IP cache has TTL and response-size cap")
    require("IS.tun>=3" in html and "tunnel check failed three times in a row" in html,
            "smart failover waits for three consecutive failed tunnel checks")

    require("sdkmanager" in workflow and "assembleDebug" in workflow,
            "CI workflow installs Android SDK and builds debug APK")
    print("NOTE: These are static checks only; they do not compile the APK or validate real VPN traffic.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
