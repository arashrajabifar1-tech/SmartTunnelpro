#!/usr/bin/env python3
"""Create a clean, reproducible source ZIP for Smart Tunnel Android."""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent / "SmartTunnelAndroid-0.22.0-source.zip"
EXCLUDED_PARTS = {".git", ".gradle", "build", ".pytest_cache", "__pycache__"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}
with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if any(part in EXCLUDED_PARTS for part in rel.parts) or path.suffix in EXCLUDED_SUFFIXES:
            continue
        archive.write(path, Path(ROOT.name) / rel)
print(f"Created {OUT} ({OUT.stat().st_size} bytes)")
