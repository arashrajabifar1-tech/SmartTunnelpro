# یادداشت انتشار Smart Tunnel v0.22.0

## تغییرها

- ShadowTLS v1/v2/v3 در UI parser با اعتبارسنجی host، port و version؛ password فقط برای v2/v3 لازم شمرده می‌شود.
- واردکردن ShadowTLS از Subscription line-based و JSON-based.
- Auto-failover پس از سه شکست پیاپیِ بررسی تونل، با حفظ cooldown/health logic موجود.
- Native tunnel probe فقط به `https://www.gstatic.com/generate_204` اجازه می‌دهد، به اتصال واقعی نیاز دارد و اگر برنامه از VPN مستثنا باشد fail می‌شود.
- IP خروجی از cache قدیمی نمایش داده نمی‌شود؛ اتصال واقعی، عدم استثنا، TTL شصت‌ثانیه‌ای، timeout، محدودیت پاسخ 4 KiB و بررسی قالب IP اعمال شده‌اند.
- WebView: file-origin cross-access خاموش، پنجره‌های JS خاموش، Safe Browsing در APIهای پشتیبانی‌شده روشن و Web debugging فقط در debug build.
- Deep-link در برابر تزریق متن به JavaScript به صورت Base64 منتقل می‌شود.
- حذف بارگذاری فونت از CDN در زمان شروع، برای کاهش درخواست خارجی و بهترشدن رفتار آفلاین. فونت Vazirmatn محلی در این آرشیو بسته‌بندی نشده؛ در نبود نصب‌شدن آن از فونت سیستمی اندروید استفاده می‌شود.
- CI آزمون‌های Static و Playwright را پیش از assembleDebug اجرا می‌کند.

## نتیجهٔ تست

`python3 scripts/validate_project.py` و `python3 tests/browser_smoke_test.py` در محیط آماده‌سازی با موفقیت اجرا شدند. این تست‌ها APK را کامپایل نمی‌کنند و عملکرد واقعی VPN را تأیید نمی‌کنند. برای اتمام انتشار، GitHub Actions باید Build موفق داشته باشد؛ سپس APK باید روی گوشی آزمایش شود.
