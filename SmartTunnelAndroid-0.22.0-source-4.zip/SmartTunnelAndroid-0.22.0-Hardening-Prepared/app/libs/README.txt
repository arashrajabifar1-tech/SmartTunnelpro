این پروژه libbox را به‌صورت وابستگی نسخه‌دار Gradle دریافت می‌کند؛ نیازی به کپی دستی AAR در این پوشه نیست.

نسخهٔ pin شده: com.github.singbox-android:libbox:1.14.3

مخزن رسمی: https://github.com/singbox-android/libbox
