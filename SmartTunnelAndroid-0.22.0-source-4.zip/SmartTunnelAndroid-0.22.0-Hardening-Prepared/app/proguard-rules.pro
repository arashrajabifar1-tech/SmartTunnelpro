-keepclassmembers class com.smarttunnel.app.bridge.SmartTunnelBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.smarttunnel.app.bridge.** { *; }
