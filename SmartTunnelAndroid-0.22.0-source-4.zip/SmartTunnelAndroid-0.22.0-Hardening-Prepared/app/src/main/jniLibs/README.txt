Native libbox binaries are expected to arrive inside the version-pinned Maven/JitPack AAR.
Do not manually copy arbitrary .so files here. If replacing libbox with a locally built AAR, document its origin, version, ABI coverage and checksum first.
