package com.smarttunnel.app.bridge

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.SystemClock
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.provider.Settings
import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.smarttunnel.app.ui.MainActivity
import com.smarttunnel.app.vpn.SmartTunnelVpnService
import io.nekohasekai.libbox.Libbox
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.net.HttpURLConnection
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * پل JS ↔ Android — نام اینترفیس در WebView: SmartTunnelNative
 * همهٔ متدها @JavascriptInterface دارند و از thread UI/JS صدا می‌شوند.
 */
class SmartTunnelBridge(
    private val activity: MainActivity,
    private val webView: WebView,
    private val requestVpnPermission: (Intent) -> Unit
) {
    private val gson = Gson()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val speedTestJobs = ConcurrentHashMap<String, Job>()
    private val speedTestConnections = ConcurrentHashMap<String, HttpURLConnection>()
    private val prefs: SharedPreferences =
        activity.getSharedPreferences("smart_tunnel_secure", Context.MODE_PRIVATE)

    private var pendingConfig: String? = null
    private var killSwitchArmed = prefs.getBoolean(KEY_KILL_SWITCH, false)
    private var excludePackages: List<String> = readStoredSplitPackages()
    private var lastExitIp: String = ""
    private var lastExitCountry: String = ""
    private val subs = linkedMapOf<String, JsonObject>()
    private val subProfiles = linkedMapOf<String, JsonObject>()

    init { loadSubscriptions() }

    // ---------- helpers ----------

    private fun evalJs(script: String) {
        activity.runOnUiThread {
            webView.evaluateJavascript(script, null)
        }
    }

    fun notifyNativeReady() {
        evalJs("try{if(typeof window.smartTunnelNativeStatusChanged==='function')window.smartTunnelNativeStatusChanged()}catch(e){}")
    }

    fun onVpnPermissionGranted() {
        val cfg = pendingConfig
        pendingConfig = null
        if (!cfg.isNullOrBlank()) {
            SmartTunnelVpnService.lastStatus = "connecting"
            activity.startVpnService(cfg)
            evalJs("try{if(typeof window.smartTunnelNativeStatusChanged==='function')window.smartTunnelNativeStatusChanged()}catch(e){}")
        }
    }

    fun onVpnPermissionDenied() {
        pendingConfig = null
        SmartTunnelVpnService.lastStatus = "disconnected"
        SmartTunnelVpnService.lastFailure = null
        evalJs("try{console.warn('VPN permission denied')}catch(e){}")
    }

    fun handleDeepLink(url: String) {
        // Pass untrusted shared/deep-link text as data, never interpolate it into JS source.
        val encoded = Base64.encodeToString(url.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        evalJs("try{if(typeof window.smartTunnelHandleUri==='function'){var t=decodeURIComponent(escape(atob('$encoded')));window.smartTunnelHandleUri(t)}}catch(e){}")
    }

    fun deliverSharedText(text: String) {
        val b64 = Base64.encodeToString(text.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        evalJs("try{if(typeof window.smartTunnelHandleUri==='function'){var t=decodeURIComponent(escape(atob('$b64')));window.smartTunnelHandleUri(t)}}catch(e){}")
    }

    // ---------- status / vpn ----------

    @JavascriptInterface
    fun getStatus(): String {
        val svc = SmartTunnelVpnService.instance
        return when {
            !com.smarttunnel.app.SmartTunnelApp.libboxReady -> "engine-unavailable"
            svc?.isConnected() == true -> "connected"
            pendingConfig != null -> "connecting"
            SmartTunnelVpnService.lastStatus == "error" -> "error:${SmartTunnelVpnService.lastFailure ?: svc?.lastError ?: "شروع موتور ناموفق بود"}"
            else -> SmartTunnelVpnService.lastStatus
        }
    }

    @JavascriptInterface
    fun getSecurityStatus(): String {
        val alwaysOnPackage = runCatching {
            Settings.Secure.getString(activity.contentResolver, "always_on_vpn_app")
        }.getOrNull().orEmpty()
        val lockdown = runCatching {
            Settings.Secure.getInt(activity.contentResolver, "always_on_vpn_lockdown", 0) == 1
        }.getOrDefault(false)
        return gson.toJson(mapOf(
            "appIsAlwaysOnVpn" to (alwaysOnPackage == activity.packageName),
            "systemLockdownEnabled" to (alwaysOnPackage == activity.packageName && lockdown)
        ))
    }

    @JavascriptInterface
    fun requestVpn(configJson: String): String {
        return try {
            if (!com.smarttunnel.app.SmartTunnelApp.libboxReady) {
                throw IllegalStateException("موتور sing-box بارگذاری نشده است؛ اتصال شروع نشد")
            }
            val config = JsonParser.parseString(configJson).asJsonObject
            val inboundArray = config.getAsJsonArray("inbounds")
            val tunInbound = inboundArray?.firstOrNull { it.isJsonObject && it.asJsonObject.get("type")?.asString == "tun" }?.asJsonObject
                ?: throw IllegalArgumentException("برای VPN سراسری، TUN را در Config فعال کن")
            if (tunInbound.get("auto_route")?.asBoolean != true) {
                throw IllegalArgumentException("گزینهٔ auto_route باید فعال باشد تا Android ترافیک را به تونل هدایت کند")
            }
            val finalTag = config.getAsJsonObject("route")?.get("final")?.asString.orEmpty()
            if (finalTag.isBlank() || finalTag == "direct") {
                throw IllegalArgumentException("مسیر نهایی روی DIRECT است؛ ابتدا یک سرور پروکسی واقعی انتخاب کن")
            }
            val outbounds = config.getAsJsonArray("outbounds")
                ?: throw IllegalArgumentException("Config خروجی outbounds ندارد")
            val nonProxyTypes = setOf("direct", "block", "dns", "urltest", "url-test", "selector", "fallback", "loadbalance")
            val hasProxy = outbounds.any { item ->
                item.isJsonObject && item.asJsonObject.get("type")?.asString?.lowercase()?.let { it !in nonProxyTypes } == true
            }
            if (!hasProxy) throw IllegalArgumentException("هنوز هیچ سرور/پروکسی واقعی اضافه نشده؛ اتصال DIRECT به‌تنهایی VPN محافظت‌کننده نیست")
            Libbox.checkConfig(configJson)
            pendingConfig = configJson
            lastExitIp = ""
            lastExitCountry = ""
            lastExitIpFetchedAt = 0L
            lastExitIpAttemptAt = 0L
            SmartTunnelVpnService.lastStatus = "connecting"
            SmartTunnelVpnService.lastFailure = null
            activity.runOnUiThread { activity.requestVpnPermission() }
            "OK"
        } catch (e: Exception) {
            pendingConfig = null
            SmartTunnelVpnService.lastStatus = "error"
            SmartTunnelVpnService.lastFailure = e.message ?: e.javaClass.simpleName
            "ERROR:${e.message ?: e.javaClass.simpleName}"
        }
    }

    @JavascriptInterface
    fun stopVpn(ignored: String?): String {
        return try {
            activity.runOnUiThread { activity.stopVpnService() }
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun getTraffic(): String {
        val t = SmartTunnelVpnService.instance?.traffic()
        val map = linkedMapOf(
            "state" to (t?.state ?: "disconnected"),
            "upBps" to (t?.upBps ?: 0L),
            "downBps" to (t?.downBps ?: 0L),
            "upTotal" to (t?.upTotal ?: 0L),
            "downTotal" to (t?.downTotal ?: 0L),
            "connectedAt" to (t?.connectedAt ?: 0L)
        )
        return gson.toJson(map)
    }

    @JavascriptInterface
    fun getExitIp(): String {
        val status = getStatus()
        if (status != "connected" || activity.packageName in excludePackages) {
            lastExitIp = ""
            lastExitCountry = ""
            lastExitIpFetchedAt = 0L
            lastExitIpAttemptAt = 0L
            return gson.toJson(mapOf("state" to if (status == "connected") "not-verifiable" else status, "ip" to "", "country" to ""))
        }
        val now = SystemClock.elapsedRealtime()
        val stale = lastExitIp.isBlank() || now - lastExitIpFetchedAt >= 60_000L
        if (stale) {
            // Clear old values before refresh so a stale exit IP is never presented as current.
            lastExitIp = ""
            lastExitCountry = ""
            if (now - lastExitIpAttemptAt >= 10_000L) {
                lastExitIpAttemptAt = now
                scope.launch { refreshExitIp() }
            }
            return gson.toJson(mapOf("state" to "checking", "ip" to "", "country" to ""))
        }
        return gson.toJson(mapOf("state" to "connected", "ip" to lastExitIp, "country" to lastExitCountry))
    }

    @Volatile private var lastExitIpAttemptAt: Long = 0L
    @Volatile private var lastExitIpFetchedAt: Long = 0L

    private suspend fun refreshExitIp() = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            if (getStatus() != "connected" || activity.packageName in excludePackages) return@withContext
            conn = (java.net.URL("https://api.ipify.org?format=json").openConnection() as HttpURLConnection).apply {
                connectTimeout = 4000
                readTimeout = 4000
                instanceFollowRedirects = false
                useCaches = false
                setRequestProperty("Accept", "application/json")
            }
            if (conn.responseCode !in 200..299) {
                lastExitIp = ""
                lastExitCountry = ""
                lastExitIpFetchedAt = 0L
                return@withContext
            }
            val body = conn.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(512)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (out.size() + count > 4096) throw IllegalArgumentException("پاسخ IP بیش از حد بزرگ است")
                    out.write(buffer, 0, count)
                }
                out.toString("UTF-8")
            }
            val ip = JsonParser.parseString(body).asJsonObject.get("ip")?.asString.orEmpty()
            val validIpv4 = Regex("""^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$""").matches(ip) &&
                ip.split('.').all { octet -> octet.toIntOrNull()?.let { it in 0..255 } == true }
            val validIpv6 = ip.contains(':') && ip.matches(Regex("^[0-9a-fA-F:.]+$")) &&
                runCatching { java.net.InetAddress.getByName(ip) is java.net.Inet6Address }.getOrDefault(false)
            val looksLikeIp = ip.length in 3..64 && (validIpv4 || validIpv6)
            if (getStatus() == "connected" && activity.packageName !in excludePackages && looksLikeIp) {
                lastExitIp = ip
                lastExitCountry = ""
                lastExitIpFetchedAt = SystemClock.elapsedRealtime()
            } else {
                lastExitIp = ""
                lastExitCountry = ""
                lastExitIpFetchedAt = 0L
            }
        } catch (_: Exception) {
            lastExitIp = ""
            lastExitCountry = ""
            lastExitIpFetchedAt = 0L
        } finally { conn?.disconnect() }
    }

    // ---------- secure storage ----------

    @JavascriptInterface
    fun secureLoad(): String? {
        return try {
            val stored = prefs.getString(KEY_SECURE, null) ?: return null
            if (stored.startsWith(DEVICE_CIPHER_PREFIX)) {
                decryptDeviceBlob(stored)
            } else {
                // One-time migration of older versions that stored the app JSON as plaintext.
                prefs.edit().putString(KEY_SECURE, encryptDeviceBlob(stored)).commit()
                stored
            }
        } catch (e: Exception) {
            Log.e(TAG, "secureLoad failed", e)
            null
        }
    }

    @JavascriptInterface
    fun secureSave(raw: String): String {
        return try {
            val encrypted = encryptDeviceBlob(raw)
            if (!prefs.edit().putString(KEY_SECURE, encrypted).commit()) throw IllegalStateException("ذخیره‌سازی انجام نشد")
            "OK"
        } catch (e: Exception) {
            Log.e(TAG, "secureSave failed", e)
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun secureClear(): String {
        return try {
            if (!prefs.edit()
                    .remove(KEY_SECURE)
                    .remove(KEY_SUBSCRIPTIONS)
                    .remove(KEY_KILL_SWITCH)
                    .remove(KEY_SPLIT_PACKAGES)
                    .commit()) {
                throw IllegalStateException("پاک‌سازی تنظیمات انجام نشد")
            }
            synchronized(subs) { subs.clear(); subProfiles.clear() }
            killSwitchArmed = false
            excludePackages = emptyList()
            runCatching {
                val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                if (keyStore.containsAlias(KEYSTORE_ALIAS)) keyStore.deleteEntry(KEYSTORE_ALIAS)
            }
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    private fun deviceKeystoreKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (keyStore.getKey(KEYSTORE_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            KEYSTORE_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    private fun encryptDeviceBlob(plain: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, deviceKeystoreKey())
        val cipherText = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        return DEVICE_CIPHER_PREFIX + Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" +
            Base64.encodeToString(cipherText, Base64.NO_WRAP)
    }

    private fun decryptDeviceBlob(payload: String): String {
        val fields = payload.split(":", limit = 4)
        require(fields.size == 4 && fields[0] == "enc" && fields[1] == "v1") { "قالب رمزنگاری محلی نامعتبر است" }
        val iv = Base64.decode(fields[2], Base64.NO_WRAP)
        val ciphertext = Base64.decode(fields[3], Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, deviceKeystoreKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    }

    @JavascriptInterface
    fun secureExport(data: String, password: String): String {
        return try {
            require(password.length >= 12) { "رمز پشتیبان باید دست‌کم ۱۲ نویسه باشد" }
            require(data.length <= 500_000) { "دادهٔ پشتیبان بیش از حد بزرگ است" }
            encryptPayload(data, password)
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun secureImport(payload: String, password: String): String {
        return try {
            decryptPayload(payload, password)
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    private fun encryptPayload(plain: String, password: String): String {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val key = deriveKey(password, salt, 210_000)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
        val obj = JsonObject()
        obj.addProperty("app", "smart-tunnel")
        obj.addProperty("v", 1)
        obj.addProperty("kdf", "PBKDF2-SHA256")
        obj.addProperty("iter", 210000)
        obj.addProperty("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
        obj.addProperty("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
        obj.addProperty("ct", Base64.encodeToString(ct, Base64.NO_WRAP))
        return obj.toString()
    }

    private fun decryptPayload(payload: String, password: String): String {
        require(payload.length <= 1_000_000) { "فایل پشتیبان بیش از حد بزرگ است" }
        val o = JsonParser.parseString(payload).asJsonObject
        require(o.get("app")?.asString == "smart-tunnel" && o.get("v")?.asInt == 1) { "این فایل پشتیبان Smart Tunnel نیست یا نسخهٔ آن پشتیبانی نمی‌شود" }
        require(o.get("kdf")?.asString == "PBKDF2-SHA256") { "روش مشتق‌سازی کلید ناشناخته است" }
        val salt = Base64.decode(o.get("salt").asString, Base64.NO_WRAP)
        val iv = Base64.decode(o.get("iv").asString, Base64.NO_WRAP)
        val ct = Base64.decode(o.get("ct").asString, Base64.NO_WRAP)
        val iter = o.get("iter")?.asInt ?: 210_000
        require(salt.size == 16 && iv.size == 12 && ct.size in 16..750_000) { "ابعاد فایل پشتیبان نامعتبر است" }
        require(iter in 100_000..1_000_000) { "هزینهٔ رمزگشایی خارج از محدودهٔ امن است" }
        val key = deriveKey(password, salt, iter)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return String(cipher.doFinal(ct), Charsets.UTF_8)
    }

    private fun deriveKey(password: String, salt: ByteArray, iter: Int): SecretKeySpec {
        require(iter in 100_000..1_000_000) { "تعداد تکرارهای KDF نامعتبر است" }
        require(salt.size == 16) { "Salt نامعتبر است" }
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(password.toCharArray(), salt, iter, 256)
        return try {
            SecretKeySpec(factory.generateSecret(spec).encoded, "AES")
        } finally {
            spec.clearPassword()
        }
    }

    // ---------- kill switch / split ----------

    @JavascriptInterface
    fun getKillSwitch(): String = gson.toJson(mapOf("armed" to killSwitchArmed))

    @JavascriptInterface
    fun setKillSwitch(v: String): String {
        return try {
            killSwitchArmed = v == "true" || v == "1"
            prefs.edit().putBoolean(KEY_KILL_SWITCH, killSwitchArmed).commit()
            // Android does not permit an app to silently turn on Lockdown; users enable it in system VPN settings.
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun getSplitTunnel(): String = gson.toJson(mapOf("excludePackages" to excludePackages))

    @JavascriptInterface
    fun setSplitTunnel(json: String): String {
        return try {
            val o = JsonParser.parseString(json).asJsonObject
            val arr = o.getAsJsonArray("excludePackages")
            val cleaned = arr?.map { it.asString.trim() }?.filter { it.matches(Regex("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+")) }?.distinct() ?: emptyList()
            excludePackages = cleaned
            val raw = gson.toJson(cleaned)
            if (!prefs.edit().putString(KEY_SPLIT_PACKAGES, raw).commit()) throw IllegalStateException("ذخیره‌سازی انجام نشد")
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    private fun readStoredSplitPackages(): List<String> = runCatching {
        val raw = prefs.getString(KEY_SPLIT_PACKAGES, "[]") ?: "[]"
        JsonParser.parseString(raw).asJsonArray.map { it.asString }
            .filter { it.matches(Regex("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+")) }.distinct()
    }.getOrDefault(emptyList())

    @JavascriptInterface
    fun openVpnSettings(ignored: String? = null): String {
        return try {
            val i = Intent(Settings.ACTION_VPN_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(i)
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    // ---------- network helpers ----------

    @JavascriptInterface
    fun tcpPing(json: String): String {
        return try {
            val o = JsonParser.parseString(json).asJsonObject
            val host = o.get("host").asString
            val port = o.get("port").asInt
            val timeout = o.get("timeoutMs")?.asInt ?: 3000
            val t0 = System.currentTimeMillis()
            Socket().use { s ->
                s.connect(InetSocketAddress(host, port), timeout)
            }
            (System.currentTimeMillis() - t0).toString()
        } catch (_: Exception) {
            "-1"
        }
    }

    @JavascriptInterface
    fun tcpPingBatch(json: String): String {
        return try {
            val o = JsonParser.parseString(json).asJsonObject
            val reqId = o.get("reqId").asString
            val timeout = o.get("timeoutMs")?.asInt ?: 3000
            val targets = o.getAsJsonArray("targets")
            scope.launch {
                val results = targets.map { el ->
                    val t = el.asJsonObject
                    val id = t.get("id").asString
                    val host = t.get("host").asString
                    val port = t.get("port").asInt
                    val ms = try {
                        val t0 = System.currentTimeMillis()
                        Socket().use { s -> s.connect(InetSocketAddress(host, port), timeout) }
                        System.currentTimeMillis() - t0
                    } catch (_: Exception) {
                        -1L
                    }
                    mapOf("id" to id, "ms" to ms)
                }
                val payload = gson.toJson(mapOf("reqId" to reqId, "results" to results))
                val safe = payload.replace("\\", "\\\\").replace("'", "\\'")
                evalJs("try{if(typeof window.smartTunnelPingResult==='function')window.smartTunnelPingResult('$safe')}catch(e){}")
            }
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    @SuppressLint("MissingPermission")
    @JavascriptInterface
    fun getWifiInfo(ignored: String? = null): String {
        return try {
            val wm = activity.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val info = wm.connectionInfo
            val ssid = info?.ssid?.trim('"')?.takeIf { it.isNotBlank() && it != "<unknown ssid>" } ?: ""
            val bssid = info?.bssid.orEmpty()
            val connected = ssid.isNotEmpty()
            gson.toJson(
                mapOf(
                    "ssid" to ssid,
                    "bssid" to bssid,
                    "secure" to true,
                    "connected" to connected
                )
            )
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    /** Reports the best non-VPN uplink using Android capabilities; performs no external probe. */
    @JavascriptInterface
    fun getNetworkInfo(ignored: String? = null): String {
        return try {
            val cm = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val candidates = cm.allNetworks.mapNotNull { network ->
                val caps = cm.getNetworkCapabilities(network) ?: return@mapNotNull null
                if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ||
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) return@mapNotNull null
                val type = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                    else -> "other"
                }
                val score = (if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) 0 else 10) + when (type) {
                    "wifi" -> 0
                    "cellular" -> 1
                    else -> 2
                }
                score to mapOf(
                    "type" to type,
                    "validated" to caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
                    "metered" to !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
                )
            }.sortedBy { it.first }
            gson.toJson(candidates.firstOrNull()?.second ?: mapOf("type" to "unknown", "validated" to false, "metered" to true))
        } catch (e: Exception) {
            gson.toJson(mapOf("type" to "unknown", "validated" to false, "metered" to true, "error" to (e.message ?: "network info unavailable")))
        }
    }

    @JavascriptInterface
    fun getGateway(ignored: String? = null): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val cm = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val net = cm.activeNetwork ?: return ""
                val props = cm.getLinkProperties(net) ?: return ""
                props.routes.firstOrNull { it.isDefaultRoute }?.gateway?.hostAddress.orEmpty()
            } else {
                ""
            }
        } catch (_: Exception) {
            ""
        }
    }

    // ---------- apps / files / notify ----------

    @JavascriptInterface
    fun listApps(ignored: String? = null): String {
        return try {
            val pm = activity.packageManager
            val apps = pm.getInstalledApplications(0)
                .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
                .map {
                    mapOf(
                        "package" to it.packageName,
                        "label" to (it.loadLabel(pm)?.toString() ?: it.packageName),
                        "system" to ((it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0)
                    )
                }
                .sortedBy { it["label"].toString().lowercase() }
            gson.toJson(apps)
        } catch (e: Exception) {
            "[]"
        }
    }

    @JavascriptInterface
    fun notify(json: String): String {
        return try {
            // حداقل: لاگ؛ می‌توان Notification کامل ساخت
            Log.i(TAG, "notify: $json")
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun saveFile(json: String): String {
        return try {
            val o = JsonParser.parseString(json).asJsonObject
            val requestedName = o.get("name").asString
            val safeName = requestedName.substringAfterLast('/').substringAfterLast('\\')
                .replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)
            require(safeName.isNotBlank() && safeName != "." && safeName != "..") { "نام فایل نامعتبر است" }
            val text = o.get("text").asString
            val dir = (activity.getExternalFilesDir(null) ?: activity.filesDir).canonicalFile
            val target = File(dir, safeName).canonicalFile
            require(target.parentFile == dir) { "مسیر ذخیره‌سازی نامعتبر است" }
            target.writeText(text)
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun shareConfig(configJson: String): String {
        return try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_TEXT, configJson)
            }
            activity.startActivity(Intent.createChooser(send, "Share config"))
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun openSfaImport(url: String): String {
        return try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            activity.startActivity(i)
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun scanQr(ignored: String? = null): String {
        // بدون وابستگی اضافه: از HTML BarcodeDetector استفاده شود
        // Native می‌تواند بعداً CameraX اضافه کند
        return "ERROR:use HTML BarcodeDetector or implement CameraX"
    }

    @JavascriptInterface
    fun parseUri(uri: String): String {
        // پارس سنگین در JS است؛ Native فقط پاس‌through خطا ندهد
        return try {
            gson.toJson(mapOf("error" to "use JS parser", "raw" to uri))
        } catch (e: Exception) {
            """{"error":"${e.message}"}"""
        }
    }

    @JavascriptInterface
    fun validateConfig(configJson: String): String {
        return try {
            JsonParser.parseString(configJson)
            if (!com.smarttunnel.app.SmartTunnelApp.libboxReady) return "ERROR:موتور sing-box آماده نیست"
            Libbox.checkConfig(configJson)
            "OK (sing-box/libbox config validation passed)"
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun testThroughTunnel(json: String): String {
        return try {
            if (!com.smarttunnel.app.SmartTunnelApp.libboxReady) throw IllegalStateException("موتور sing-box بارگذاری نشده است")
            val input = JsonParser.parseString(json).asJsonObject
            val reqId = input.get("reqId")?.asString.orEmpty()
            require(Regex("^[A-Za-z0-9_-]{1,80}$").matches(reqId)) { "شناسهٔ آزمون نامعتبر است" }
            val url = input.get("url")?.asString ?: "https://www.gstatic.com/generate_204"
            val parsed = Uri.parse(url)
            require(parsed.scheme.equals("https", true) && parsed.host.equals("www.gstatic.com", true) && parsed.path == "/generate_204" && parsed.userInfo == null && (parsed.port == -1 || parsed.port == 443) && parsed.query == null && parsed.fragment == null) {
                "آدرس تست مجاز نیست؛ فقط gstatic generate_204 پشتیبانی می‌شود"
            }
            require(getStatus() == "connected") { "VPN واقعاً متصل نیست؛ تست تونل اجرا نشد" }
            require(activity.packageName !in excludePackages) { "برنامه از VPN مستثنا شده و تست عبوری قابل تأیید نیست" }
            val timeout = (input.get("timeoutMs")?.asInt ?: 5000).coerceIn(1000, 8000)
            scope.launch {
                val t0 = SystemClock.elapsedRealtime()
                var ok = false
                var conn: HttpURLConnection? = null
                try {
                    if (getStatus() != "connected") throw IllegalStateException("VPN هنگام شروع تست قطع شد")
                    conn = (java.net.URL("https://www.gstatic.com/generate_204").openConnection() as HttpURLConnection).apply {
                        connectTimeout = timeout
                        readTimeout = timeout
                        requestMethod = "GET"
                        instanceFollowRedirects = false
                        useCaches = false
                        setRequestProperty("Cache-Control", "no-cache")
                    }
                    conn.connect()
                    ok = conn.responseCode == 204 && getStatus() == "connected"
                } catch (_: Exception) {
                    ok = false
                } finally { conn?.disconnect() }
                val elapsed = SystemClock.elapsedRealtime() - t0
                val payload = gson.toJson(mapOf("reqId" to reqId, "ok" to ok, "ms" to elapsed))
                evalJs("try{if(typeof window.smartTunnelTunnelTestResult==='function')window.smartTunnelTunnelTestResult(${gson.toJson(payload)})}catch(e){}")
            }
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message ?: "خطای تست تونل"}"
        }
    }

    /**
     * Downloads a bounded payload from a fixed HTTPS benchmark endpoint. The request is intentionally
     * not URL-configurable from JS (prevents arbitrary URL/SSRF abuse) and only records complete tests
     * while Android reports the VPN service as connected.
     */
    @JavascriptInterface
    fun speedTestThroughTunnel(json: String): String {
        return try {
            if (!com.smarttunnel.app.SmartTunnelApp.libboxReady) {
                throw IllegalStateException("موتور sing-box بارگذاری نشده است")
            }
            if (getStatus() != "connected") throw IllegalStateException("برای تست سرعت، VPN باید واقعاً متصل باشد")
            if (activity.packageName in excludePackages) {
                throw IllegalStateException("برنامهٔ Smart Tunnel از VPN مستثنا شده است؛ تست عبوری قابل تأیید نیست")
            }
            val input = JsonParser.parseString(json).asJsonObject
            val reqId = input.get("reqId")?.asString.orEmpty()
            if (!Regex("^[A-Za-z0-9_-]{1,80}$").matches(reqId)) {
                throw IllegalArgumentException("شناسهٔ تست نامعتبر است")
            }
            val sizeMb = input.get("sizeMB")?.asInt ?: 2
            if (sizeMb !in 1..10) throw IllegalArgumentException("اندازهٔ تست باید بین 1 و 10 مگابایت باشد")
            val timeoutMs = (input.get("timeoutMs")?.asInt ?: 15000).coerceIn(5000, 20000)
            if (speedTestJobs.containsKey(reqId)) throw IllegalArgumentException("این تست قبلاً در حال اجرا است")
            val expectedBytes = sizeMb.toLong() * 1024L * 1024L
            val job = scope.launch(start = CoroutineStart.LAZY) {
                var connection: HttpURLConnection? = null
                var totalBytes = 0L
                var statusCode = -1
                var errorText = ""
                var success = false
                val started = SystemClock.elapsedRealtime()
                try {
                    if (getStatus() != "connected") throw IllegalStateException("VPN پیش از شروع دانلود قطع شد")
                    val url = java.net.URL("https://speed.cloudflare.com/__down?bytes=$expectedBytes")
                    connection = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = timeoutMs
                        readTimeout = timeoutMs
                        useCaches = false
                        instanceFollowRedirects = false
                        setRequestProperty("Cache-Control", "no-cache, no-store")
                        setRequestProperty("Pragma", "no-cache")
                        setRequestProperty("Accept-Encoding", "identity")
                        setRequestProperty("User-Agent", "SmartTunnel-SpeedTest/0.22.0")
                    }
                    speedTestConnections[reqId] = connection!!
                    statusCode = connection!!.responseCode
                    if (statusCode !in 200..299) throw java.io.IOException("سرور تست HTTP $statusCode برگرداند")
                    connection!!.inputStream.buffered().use { stream ->
                        val buffer = ByteArray(16 * 1024)
                        while (true) {
                            val count = stream.read(buffer)
                            if (count < 0) break
                            totalBytes += count.toLong()
                            if (totalBytes > expectedBytes + 1024L) throw java.io.IOException("حجم پاسخ با درخواست تست مطابقت نداشت")
                        }
                    }
                    if (totalBytes < expectedBytes) throw java.io.IOException("دانلود کامل نشد: $totalBytes از $expectedBytes بایت")
                    if (getStatus() != "connected") throw java.io.IOException("VPN هنگام تست قطع شد؛ نتیجه معتبر نیست")
                    success = true
                } catch (e: Exception) {
                    errorText = (e.message ?: e.javaClass.simpleName).take(180)
                } finally {
                    speedTestConnections.remove(reqId)
                    try { connection?.disconnect() } catch (_: Exception) {}
                    val elapsed = (SystemClock.elapsedRealtime() - started).coerceAtLeast(1L)
                    // bytes * 8 / milliseconds = decimal Kbps
                    val kbps = if (success) totalBytes.toDouble() * 8.0 / elapsed.toDouble() else 0.0
                    val payload = gson.toJson(mapOf(
                        "reqId" to reqId,
                        "ok" to success,
                        "bytes" to totalBytes,
                        "expectedBytes" to expectedBytes,
                        "elapsedMs" to elapsed,
                        "kbps" to kbps,
                        "mbps" to (kbps / 1000.0),
                        "httpStatus" to statusCode,
                        "error" to errorText
                    ))
                    speedTestJobs.remove(reqId)
                    evalJs("try{if(typeof window.smartTunnelSpeedTestResult==='function')window.smartTunnelSpeedTestResult(${gson.toJson(payload)})}catch(e){}")
                }
            }
            if (speedTestJobs.putIfAbsent(reqId, job) != null) throw IllegalArgumentException("شناسهٔ تست تکراری است")
            job.start()
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message ?: e.javaClass.simpleName}"
        }
    }

    @JavascriptInterface
    fun cancelSpeedTest(reqId: String): String {
        return try {
            if (!Regex("^[A-Za-z0-9_-]{1,80}$").matches(reqId)) return "ERROR:شناسهٔ تست نامعتبر است"
            try { speedTestConnections[reqId]?.disconnect() } catch (_: Exception) {}
            speedTestJobs[reqId]?.cancel()
            "OK"
        } catch (e: Exception) {
            "ERROR:${e.message ?: e.javaClass.simpleName}"
        }
    }


    // ---------- native subscriptions: fetch, decode and persist real profiles ----------

    @JavascriptInterface
    fun subscriptionAdd(json: String): String {
        return try {
            val input = JsonParser.parseString(json).asJsonObject
            val urls = mutableListOf<String>()
            input.getAsJsonArray("urls")?.forEach { if (it.isJsonPrimitive) urls += it.asString.trim() }
            input.get("url")?.asString?.trim()?.takeIf { it.isNotBlank() }?.let { if (it !in urls) urls.add(0, it) }
            if (urls.isEmpty()) throw IllegalArgumentException("لینک Subscription خالی است")
            urls.forEach { validateSubscriptionUrl(it) }
            val id = "sub-" + UUID.randomUUID().toString().take(8)
            val record = JsonObject().apply {
                addProperty("id", id)
                addProperty("name", input.get("name")?.asString?.takeIf { it.isNotBlank() } ?: "Subscription")
                addProperty("url", urls.first())
                add("urls", gson.toJsonTree(urls))
                addProperty("refreshHours", (input.get("refreshHours")?.asInt ?: 6).coerceIn(1, 168))
                addProperty("enabled", input.get("enabled")?.asBoolean ?: true)
                addProperty("status", "IDLE")
                addProperty("profiles", 0)
                addProperty("updatedAt", 0L)
            }
            synchronized(subs) { subs[id] = record; persistSubscriptionsLocked() }
            id
        } catch (e: Exception) {
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun subscriptionRefresh(id: String): String {
        val record = synchronized(subs) { subs[id]?.deepCopy() } ?: return "ERROR:Subscription پیدا نشد"
        return try {
            val urls = mutableListOf<String>()
            record.getAsJsonArray("urls")?.forEach { urls += it.asString }
            if (urls.isEmpty()) record.get("url")?.asString?.let { urls += it }
            var lastError = "دانلود ناموفق"
            var successfulUrl = ""
            var body = ""
            var userinfo = ""
            for (url in urls) {
                try {
                    val fetched = fetchSubscription(url)
                    body = normalizeSubscriptionBody(fetched.first)
                    userinfo = fetched.second
                    successfulUrl = url
                    break
                } catch (e: Exception) {
                    lastError = e.message ?: "خطای شبکه"
                }
            }
            if (successfulUrl.isBlank()) throw IllegalStateException(lastError)
            val parsed = parseSubscriptionProfiles(id, record.get("name")?.asString ?: "Subscription", body)
            if (parsed.isEmpty()) throw IllegalArgumentException("محتوای Subscription شامل مسیر قابل‌استفاده‌ای نبود")
            synchronized(subs) {
                subProfiles.entries.removeAll { it.value.get("sourceId")?.asString == id }
                parsed.forEach { subProfiles[it.get("id").asString] = it }
                record.addProperty("url", successfulUrl)
                record.addProperty("status", "OK")
                record.addProperty("profiles", parsed.size)
                record.addProperty("updatedAt", System.currentTimeMillis())
                record.addProperty("error", "")
                record.addProperty("userinfo", userinfo)
                subs[id] = record
                persistSubscriptionsLocked()
            }
            Log.i(TAG, "Subscription refreshed: $id (${parsed.size} profiles)")
            "OK"
        } catch (e: Exception) {
            synchronized(subs) {
                subs[id]?.apply { addProperty("status", "ERROR"); addProperty("error", e.message ?: "Refresh failed") }
                persistSubscriptionsLocked()
            }
            Log.w(TAG, "Subscription refresh failed for $id", e)
            "ERROR:${e.message}"
        }
    }

    @JavascriptInterface
    fun subscriptionRefreshAll(ignored: String? = null): String {
        val ids = synchronized(subs) { subs.values.filter { it.get("enabled")?.asBoolean != false }.map { it.get("id").asString } }
        var ok = 0
        ids.forEach { if (subscriptionRefresh(it) == "OK") ok++ }
        return "OK:$ok/${ids.size}"
    }

    @JavascriptInterface
    fun subscriptionRemove(id: String): String {
        synchronized(subs) {
            subs.remove(id)
            subProfiles.entries.removeAll { it.value.get("sourceId")?.asString == id }
            persistSubscriptionsLocked()
        }
        return "OK"
    }

    @JavascriptInterface
    fun subscriptionStatus(ignored: String? = null): String = synchronized(subs) { gson.toJson(subs.values.toList()) }

    @JavascriptInterface
    fun subscriptionProfiles(ignored: String? = null): String = synchronized(subProfiles) { gson.toJson(subProfiles.values.toList()) }

    @JavascriptInterface
    fun subscriptionHealthCheck(json: String): String {
        val began = SystemClock.elapsedRealtime()
        return try {
            val input = JsonParser.parseString(json).asJsonObject
            val timeoutMs = (input.get("timeoutMs")?.asInt ?: 900).coerceIn(250, 1500)
            val probeUrl = input.get("probeUrl")?.asString ?: "https://www.gstatic.com/generate_204"
            val profiles = synchronized(subProfiles) { subProfiles.values.map { it.deepCopy() }.take(48) }
            val executor = Executors.newFixedThreadPool(8)
            val httpProbe = executor.submit(Callable { probeHttps(probeUrl, timeoutMs) })
            val futures = profiles.map { p -> executor.submit(Callable {
                val endpoint = profileEndpoint(p)
                val t0 = SystemClock.elapsedRealtime()
                val tcpMs = if (endpoint == null) -1L else tcpConnect(endpoint.first, endpoint.second, timeoutMs)
                mapOf("id" to p.get("id").asString, "name" to (p.get("name")?.asString ?: ""), "tcpOk" to (tcpMs >= 0), "tcpMs" to tcpMs, "host" to (endpoint?.first ?: ""), "port" to (endpoint?.second ?: 0), "elapsedMs" to (SystemClock.elapsedRealtime() - t0))
            }) }
            val http = try { httpProbe.get((timeoutMs + 400L), TimeUnit.MILLISECONDS) } catch (_: Exception) { mapOf("ok" to false, "ms" to -1L) }
            val results = futures.map { f -> try { f.get((timeoutMs + 500L), TimeUnit.MILLISECONDS) } catch (_: Exception) { mapOf("id" to "", "tcpOk" to false, "tcpMs" to -1L, "host" to "", "port" to 0) } }
            executor.shutdownNow()
            gson.toJson(mapOf("elapsedMs" to (SystemClock.elapsedRealtime() - began), "completedUnder2s" to (SystemClock.elapsedRealtime() - began < 2000), "httpProbe" to http, "results" to results.map { r -> r + mapOf("httpOk" to (http["ok"] == true), "httpMs" to (http["ms"] ?: -1L)) }))
        } catch (e: Exception) {
            gson.toJson(mapOf("elapsedMs" to (SystemClock.elapsedRealtime() - began), "completedUnder2s" to false, "error" to (e.message ?: "Health check failed"), "results" to emptyList<Any>()))
        }
    }

    @JavascriptInterface
    fun subscriptionUserinfo(id: String): String = synchronized(subs) { subs[id]?.get("userinfo")?.asString.orEmpty() }

    private fun validateSubscriptionUrl(url: String) {
        val uri = Uri.parse(url)
        require(uri.scheme.equals("https", true) && !uri.host.isNullOrBlank()) {
            "برای محافظت از اطلاعات اشتراک، فقط لینک HTTPS پشتیبانی می‌شود"
        }
    }

    private fun fetchSubscription(url: String): Pair<String, String> {
        var currentUrl = url
        repeat(6) { hop ->
            validateSubscriptionUrl(currentUrl)
            val conn = (java.net.URL(currentUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 9000
                readTimeout = 12000
                instanceFollowRedirects = false // do not leak a subscription token to an HTTP redirect
                useCaches = false
                setRequestProperty("Accept", "text/plain, application/json, */*")
                setRequestProperty("User-Agent", "SmartTunnel/0.22.0 Android")
            }
            try {
                val code = conn.responseCode
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location")
                        ?: throw IllegalStateException("پاسخ redirect فاقد Location است")
                    val nextUrl = java.net.URL(java.net.URL(currentUrl), location).toString()
                    validateSubscriptionUrl(nextUrl) // validate scheme before making the next request
                    if (hop == 5) throw IllegalStateException("تعداد redirectها بیش از حد مجاز است")
                    currentUrl = nextUrl
                    return@repeat
                }
                if (code !in 200..299) throw IllegalStateException("HTTP $code")
                val builder = StringBuilder()
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                    val buffer = CharArray(8192)
                    var total = 0
                    while (true) {
                        val count = reader.read(buffer)
                        if (count < 0) break
                        total += count
                        if (total > MAX_SUB_BYTES) throw IllegalArgumentException("Subscription بزرگ‌تر از حد مجاز است")
                        builder.append(buffer, 0, count)
                    }
                }
                return builder.toString() to conn.getHeaderField("Subscription-Userinfo").orEmpty()
            } finally {
                conn.disconnect()
            }
        }
        throw IllegalStateException("تعداد redirectها بیش از حد مجاز است")
    }

    private fun normalizeSubscriptionBody(source: String): String {
        val text = source.trim().removePrefix("\uFEFF")
        if (text.isEmpty() || text.startsWith("{") || text.startsWith("[")) return text
        if (text.lineSequence().any { Regex("(?i)^(vless|vmess|trojan|ss|socks5?|https?|hysteria2?|hy2|tuic|wireguard|shadowtls)://").containsMatchIn(it.trim()) }) return text
        val compact = text.filterNot { it.isWhitespace() }
        val decoded = runCatching { String(Base64.decode(compact, Base64.DEFAULT), Charsets.UTF_8).trim() }.getOrNull()
        return if (!decoded.isNullOrBlank() && (decoded.startsWith("{") || decoded.startsWith("[") || decoded.contains(Regex("(?i)(vless|vmess|trojan|ss|socks5?|https?|hysteria2?|hy2|tuic|wireguard|shadowtls)://")))) decoded else text
    }

    private fun parseSubscriptionProfiles(sourceId: String, subscriptionName: String, body: String): List<JsonObject> {
        val result = mutableListOf<JsonObject>()
        if (body.startsWith("{") || body.startsWith("[")) {
            val parsed = JsonParser.parseString(body)
            val candidates = when {
                parsed.isJsonArray -> parsed.asJsonArray.toList()
                parsed.isJsonObject && parsed.asJsonObject.has("outbounds") -> parsed.asJsonObject.getAsJsonArray("outbounds").toList()
                parsed.isJsonObject && parsed.asJsonObject.has("type") -> listOf(parsed)
                else -> emptyList()
            }
            candidates.forEach { el ->
                if (!el.isJsonObject) return@forEach
                val outbound = el.asJsonObject
                val type = outbound.get("type")?.asString.orEmpty().lowercase()
                if (type !in ALLOWED_SUB_TYPES || type in setOf("direct", "block", "dns", "urltest", "selector", "fallback", "url-test")) return@forEach
                result += JsonObject().apply {
                    addProperty("id", UUID.randomUUID().toString())
                    addProperty("sourceId", sourceId)
                    addProperty("name", outbound.get("tag")?.asString ?: "$subscriptionName ${result.size + 1}")
                    addProperty("type", if (type == "socks") "socks5" else type)
                    addProperty("address", gson.toJson(outbound))
                    addProperty("user", "")
                    addProperty("pass", "")
                    addProperty("note", "Imported from $subscriptionName")
                    addProperty("group", subscriptionName)
                    addProperty("enabled", true)
                }
            }
            return result
        }
        val lines = body.lineSequence().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("#") && !it.startsWith("//") }.toList()
        for (line in lines) {
            val scheme = line.substringBefore("://", "").lowercase()
            val type = when (scheme) {
                "vless" -> "vless"
                "vmess" -> "vmess"
                "trojan" -> "trojan"
                "ss" -> "shadowsocks"
                "socks", "socks5" -> "socks5"
                "http", "https" -> "http"
                "hysteria", "hysteria2", "hy2" -> "hysteria2"
                "tuic" -> "tuic"
                "wireguard" -> "wireguard"
                "shadowtls" -> "shadowtls"
                else -> continue
            }
            result += JsonObject().apply {
                addProperty("id", UUID.randomUUID().toString())
                addProperty("sourceId", sourceId)
                addProperty("name", extractUriName(line) ?: "$subscriptionName ${result.size + 1}")
                addProperty("type", type)
                addProperty("address", line.replaceFirst(Regex("(?i)^hy2://"), "hysteria2://").replaceFirst(Regex("(?i)^hysteria://"), "hysteria2://"))
                addProperty("user", "")
                addProperty("pass", "")
                addProperty("note", "Imported from $subscriptionName")
                addProperty("group", subscriptionName)
                addProperty("enabled", true)
            }
        }
        return result
    }

    private fun extractUriName(line: String): String? = runCatching {
        val raw = line.substringAfter('#', "").takeIf { it.isNotBlank() } ?: return null
        java.net.URLDecoder.decode(raw, "UTF-8").takeIf { it.isNotBlank() }
    }.getOrNull()

    private fun profileEndpoint(profile: JsonObject): Pair<String, Int>? = runCatching {
        val type = profile.get("type")?.asString.orEmpty()
        val raw = profile.get("address")?.asString.orEmpty().trim()
        if (raw.startsWith("{")) {
            val o = JsonParser.parseString(raw).asJsonObject
            o.get("server")?.asString.orEmpty() to (o.get("server_port")?.asInt ?: 0)
        } else if (type == "vmess") {
            val payload = raw.removePrefix("vmess://").substringBefore('#')
            val obj = JsonParser.parseString(String(Base64.decode(payload, Base64.URL_SAFE or Base64.DEFAULT), Charsets.UTF_8)).asJsonObject
            obj.get("add").asString to obj.get("port").asInt
        } else {
            val uri = java.net.URI(raw)
            uri.host.orEmpty() to uri.port
        }
    }.getOrNull()?.takeIf { it.first.isNotBlank() && it.second in 1..65535 }

    private fun tcpConnect(host: String, port: Int, timeoutMs: Int): Long = try {
        val start = SystemClock.elapsedRealtime()
        Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
        SystemClock.elapsedRealtime() - start
    } catch (_: Exception) { -1L }

    private fun probeHttps(rawUrl: String, timeoutMs: Int): Map<String, Any> {
        var conn: HttpURLConnection? = null
        val start = SystemClock.elapsedRealtime()
        return try {
            require(rawUrl.startsWith("https://", true)) { "Health probe must use HTTPS" }
            conn = java.net.URL(rawUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs
            conn.requestMethod = "GET"
            conn.useCaches = false
            conn.connect()
            val code = conn.responseCode
            mapOf("ok" to (code in 200..399 || code == 204), "ms" to (SystemClock.elapsedRealtime() - start), "code" to code)
        } catch (e: Exception) {
            mapOf("ok" to false, "ms" to -1L, "error" to (e.message ?: "Probe failed"))
        } finally { conn?.disconnect() }
    }

    private fun loadSubscriptions() {
        try {
            val payload = prefs.getString(KEY_SUBSCRIPTIONS, null) ?: return
            val plain = decryptDeviceBlob(payload)
            val root = JsonParser.parseString(plain).asJsonObject
            root.getAsJsonArray("subscriptions")?.forEach { el -> if (el.isJsonObject) { val o = el.asJsonObject; subs[o.get("id").asString] = o } }
            root.getAsJsonArray("profiles")?.forEach { el -> if (el.isJsonObject) { val o = el.asJsonObject; subProfiles[o.get("id").asString] = o } }
        } catch (e: Exception) {
            Log.w(TAG, "Stored subscriptions could not be loaded", e)
        }
    }

    private fun persistSubscriptionsLocked() {
        val raw = gson.toJson(mapOf("subscriptions" to subs.values.toList(), "profiles" to subProfiles.values.toList()))
        prefs.edit().putString(KEY_SUBSCRIPTIONS, encryptDeviceBlob(raw)).commit()
    }

    // ---------- P2P / SMS stubs ----------

    @JavascriptInterface
    fun shareConfigP2P(json: String): String = "ERROR:WiFi Direct not implemented yet"

    @JavascriptInterface
    fun receiveConfigP2P(ignored: String? = null): String = "ERROR:WiFi Direct not implemented yet"

    @JavascriptInterface
    fun sendSms(json: String): String = "ERROR:SMS permission / not implemented"

    companion object {
        private const val TAG = "SmartTunnelBridge"
        private const val KEY_SECURE = "secure_blob"
        private const val KEY_SUBSCRIPTIONS = "subscriptions_blob"
        private const val KEY_KILL_SWITCH = "kill_switch_armed"
        private const val KEY_SPLIT_PACKAGES = "split_exclude_packages"
        private const val KEYSTORE_ALIAS = "smart-tunnel-device-data-v1"
        private const val DEVICE_CIPHER_PREFIX = "enc:v1:"
        private const val MAX_SUB_BYTES = 4 * 1024 * 1024
        private val ALLOWED_SUB_TYPES = setOf("vless", "vmess", "trojan", "shadowsocks", "socks", "http", "wireguard", "hysteria2", "tuic", "shadowtls")
    }
}
