package com.smarttunnel.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.util.Log
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.SetupOptions
import java.util.Locale
import java.io.File

class SmartTunnelApp : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_VPN,
                "Smart Tunnel VPN",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }

        // Initialize the embedded sing-box core once per process before a VPN session starts.
        try {
            filesDir.mkdirs()
            cacheDir.mkdirs()
            val workingDir = File(filesDir, "sing-box-working").apply { mkdirs() }
            Libbox.setLocale(Locale.getDefault().toLanguageTag())
            Libbox.setup(SetupOptions().apply {
                basePath = filesDir.absolutePath
                workingPath = workingDir.absolutePath
                tempPath = cacheDir.absolutePath
                fixAndroidStack = Build.VERSION.SDK_INT < Build.VERSION_CODES.O
                logMaxLines = 1500
                debug = BuildConfig.DEBUG
                appVersion = BuildConfig.VERSION_CODE.toString()
                appMarketingVersion = BuildConfig.VERSION_NAME
                crashReportSource = "SmartTunnel"
            })
            libboxReady = true
            Log.i("SmartTunnelApp", "Embedded sing-box initialized")
        } catch (e: Throwable) {
            // Keep the UI available and report the engine as unavailable instead of crashing on a JNI load error.
            libboxReady = false
            Log.e("SmartTunnelApp", "sing-box initialization failed", e)
        }
    }

    companion object {
        const val CHANNEL_VPN = "smart_tunnel_vpn"
        lateinit var instance: SmartTunnelApp
            private set
        @Volatile var libboxReady: Boolean = false
            private set
    }
}
