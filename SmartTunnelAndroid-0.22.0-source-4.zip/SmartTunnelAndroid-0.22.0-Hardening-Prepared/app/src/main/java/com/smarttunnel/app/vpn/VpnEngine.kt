package com.smarttunnel.app.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.IpPrefix
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.Process
import android.os.SystemClock
import android.system.OsConstants
import android.net.TrafficStats
import android.util.Log
import com.smarttunnel.app.SmartTunnelApp
import io.nekohasekai.libbox.AutoRedirectHandler
import io.nekohasekai.libbox.AutoRedirectSession
import io.nekohasekai.libbox.BridgeOptions
import io.nekohasekai.libbox.BridgeSession
import io.nekohasekai.libbox.CommandServer
import io.nekohasekai.libbox.CommandServerHandler
import io.nekohasekai.libbox.ConnectionOwner
import io.nekohasekai.libbox.InterfaceUpdateListener
import io.nekohasekai.libbox.Libbox
import io.nekohasekai.libbox.LocalDNSTransport
import io.nekohasekai.libbox.NeighborEntry
import io.nekohasekai.libbox.NeighborEntryIterator
import io.nekohasekai.libbox.NeighborUpdateListener
import io.nekohasekai.libbox.NetworkInterface as BoxNetworkInterface
import io.nekohasekai.libbox.NetworkInterfaceIterator
import io.nekohasekai.libbox.Notification
import io.nekohasekai.libbox.OverrideOptions
import io.nekohasekai.libbox.PlatformInterface
import io.nekohasekai.libbox.PlatformUser
import io.nekohasekai.libbox.ShellSession
import io.nekohasekai.libbox.StringIterator
import io.nekohasekai.libbox.SystemProxyStatus
import io.nekohasekai.libbox.TunOptions
import io.nekohasekai.libbox.WIFIState
import java.net.Inet6Address
import java.net.InetSocketAddress
import java.net.NetworkInterface as JavaNetworkInterface
import java.util.Collections
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Embedded sing-box runtime. This replaces the former TUN-only stub.
 * The libbox AAR is supplied by the pinned Maven/JitPack dependency in app/build.gradle.kts.
 */
class VpnEngine(private val service: VpnService) : PlatformInterface, CommandServerHandler {

    data class Traffic(
        val state: String,
        val upBps: Long,
        val downBps: Long,
        val upTotal: Long,
        val downTotal: Long,
        val connectedAt: Long
    )

    private val running = AtomicBoolean(false)
    private var tunFd: ParcelFileDescriptor? = null
    private var commandServer: CommandServer? = null
    private var connectedAt = 0L
    private var lastTrafficSampleMs = 0L
    private var lastTxBytes = -1L
    private var lastRxBytes = -1L
    private var upBps = 0L
    private var downBps = 0L
    private val upTotal = AtomicLong(0)
    private val downTotal = AtomicLong(0)
    @Volatile private var defaultInterfaceListener: InterfaceUpdateListener? = null
    @Volatile private var networkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var lastError: String? = null

    @Volatile
    var lastConfig: String? = null
        private set

    fun isRunning(): Boolean = running.get()
    fun getLastError(): String? = lastError

    /** Starts a genuine libbox CommandServer; returns null only after the core accepts the config. */
    @Synchronized
    fun start(configJson: String): String? {
        stop()
        lastError = null
        lastConfig = configJson
        return try {
            if (!SmartTunnelApp.libboxReady) error("موتور sing-box بارگذاری نشده است؛ فایل AAR/ABI یا راه‌اندازی libbox را بررسی کنید")
            require(configJson.isNotBlank()) { "Config خالی است" }
            // CommandServer validates the sing-box schema and starts the configured services.
            val server = CommandServer(this, this)
            server.start()
            try {
                server.startOrReloadService(configJson, OverrideOptions())
            } catch (e: Exception) {
                runCatching { server.closeService() }
                runCatching { server.close() }
                throw e
            }
            commandServer = server
            connectedAt = System.currentTimeMillis()
            lastTrafficSampleMs = SystemClock.elapsedRealtime()
            lastTxBytes = TrafficStats.getUidTxBytes(Process.myUid())
            lastRxBytes = TrafficStats.getUidRxBytes(Process.myUid())
            upBps = 0
            downBps = 0
            running.set(true)
            Log.i(TAG, "Embedded sing-box service started")
            null
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            running.set(false)
            closeTun()
            Log.e(TAG, "sing-box start failed", e)
            "ERROR:${lastError}"
        }
    }

    @Synchronized
    fun stop() {
        running.set(false)
        val server = commandServer
        commandServer = null
        if (server != null) {
            runCatching { server.closeService() }.onFailure { Log.w(TAG, "closeService: ${it.message}") }
            runCatching { server.close() }.onFailure { Log.w(TAG, "CommandServer.close: ${it.message}") }
        }
        closeTun()
        stopDefaultInterfaceMonitor(defaultInterfaceListener)
        defaultInterfaceListener = null
        connectedAt = 0L
        lastTrafficSampleMs = 0L
        upBps = 0L
        downBps = 0L
    }

    private fun closeTun() {
        val pfd = tunFd
        tunFd = null
        runCatching { pfd?.close() }
    }

    /** The core's counters are not exposed through the old UI contract; these are real app-UID deltas. */
    @Synchronized
    fun traffic(): Traffic {
        if (!running.get()) return Traffic("disconnected", 0, 0, upTotal.get(), downTotal.get(), 0)
        val now = SystemClock.elapsedRealtime()
        val tx = TrafficStats.getUidTxBytes(Process.myUid())
        val rx = TrafficStats.getUidRxBytes(Process.myUid())
        if (lastTrafficSampleMs > 0 && tx >= 0 && rx >= 0 && lastTxBytes >= 0 && lastRxBytes >= 0) {
            val elapsed = (now - lastTrafficSampleMs).coerceAtLeast(1)
            val txDelta = (tx - lastTxBytes).coerceAtLeast(0)
            val rxDelta = (rx - lastRxBytes).coerceAtLeast(0)
            upBps = txDelta * 1000L / elapsed
            downBps = rxDelta * 1000L / elapsed
            upTotal.addAndGet(txDelta)
            downTotal.addAndGet(rxDelta)
        } else {
            upBps = 0L
            downBps = 0L
        }
        lastTrafficSampleMs = now
        lastTxBytes = tx
        lastRxBytes = rx
        return Traffic("connected", upBps, downBps, upTotal.get(), downTotal.get(), connectedAt)
    }

    // ---------------- PlatformInterface: Android VPN/TUN ----------------

    override fun usePlatformAutoDetectInterfaceControl(): Boolean = true

    override fun autoDetectInterfaceControl(fd: Int) {
        if (!service.protect(fd)) error("Android نتوانست سوکت sing-box را از VPN مستثنا کند")
    }

    override fun openTun(options: TunOptions): Int {
        if (VpnService.prepare(service) != null) error("مجوز VPN صادر نشده است")
        closeTun()
        val builder = service.Builder().setSession("Smart Tunnel • sing-box").setMtu(options.mtu)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(isUnderlyingNetworkMetered())

        val v4 = options.inet4Address
        while (v4.hasNext()) {
            val address = v4.next()
            builder.addAddress(address.address(), address.prefix())
        }
        val v6 = options.inet6Address
        while (v6.hasNext()) {
            val address = v6.next()
            builder.addAddress(address.address(), address.prefix())
        }

        if (options.autoRoute) {
            if (options.dnsMode.value != Libbox.DNSModeDisabled) {
                val dns = options.dnsServerAddress
                while (dns.hasNext()) builder.addDnsServer(dns.next())
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val v4Routes = options.inet4RouteAddress
                if (v4Routes.hasNext()) {
                    while (v4Routes.hasNext()) builder.addRoute(v4Routes.next().toIpPrefix())
                } else if (options.inet4Address.hasNext()) {
                    builder.addRoute("0.0.0.0", 0)
                }
                val v6Routes = options.inet6RouteAddress
                if (v6Routes.hasNext()) {
                    while (v6Routes.hasNext()) builder.addRoute(v6Routes.next().toIpPrefix())
                } else if (options.inet6Address.hasNext()) {
                    builder.addRoute("::", 0)
                }
                val ex4 = options.inet4RouteExcludeAddress
                while (ex4.hasNext()) builder.excludeRoute(ex4.next().toIpPrefix())
                val ex6 = options.inet6RouteExcludeAddress
                while (ex6.hasNext()) builder.excludeRoute(ex6.next().toIpPrefix())
            } else {
                val v4Ranges = options.inet4RouteRange
                while (v4Ranges.hasNext()) {
                    val route = v4Ranges.next()
                    builder.addRoute(route.address(), route.prefix())
                }
                val v6Ranges = options.inet6RouteRange
                while (v6Ranges.hasNext()) {
                    val route = v6Ranges.next()
                    builder.addRoute(route.address(), route.prefix())
                }
            }

            // Prefer an explicit include-list, otherwise apply Config + UI exclusions.
            val includePackages = options.includePackage
            if (includePackages.hasNext()) {
                while (includePackages.hasNext()) {
                    val pkg = includePackages.next()
                    runCatching { builder.addAllowedApplication(pkg) }
                        .onFailure { Log.w(TAG, "Cannot include package $pkg: ${it.message}") }
                }
            } else {
                val configExclusions = options.excludePackage
                while (configExclusions.hasNext()) {
                    val pkg = configExclusions.next()
                    runCatching { builder.addDisallowedApplication(pkg) }
                        .onFailure { Log.w(TAG, "Cannot exclude package $pkg: ${it.message}") }
                }
                for (pkg in readSplitExclusions()) {
                    runCatching { builder.addDisallowedApplication(pkg) }
                        .onFailure { Log.w(TAG, "Cannot exclude package $pkg: ${it.message}") }
                }
            }
        }

        val pfd = builder.establish() ?: error("Android نتوانست TUN را ایجاد کند")
        tunFd = pfd
        Log.i(TAG, "Android TUN established (fd=${pfd.fd})")
        return pfd.fd
    }

    /** Be conservative about data billing: never tell Android a cellular/metred uplink is unmetered. */
    private fun isUnderlyingNetworkMetered(): Boolean = runCatching {
        val cm = service.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val candidates = cm.allNetworks.mapNotNull { network ->
            val caps = cm.getNetworkCapabilities(network) ?: return@mapNotNull null
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ||
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) return@mapNotNull null
            val score = (if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) 0 else 10) + when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 0
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> 1
                else -> 2
            }
            score to caps
        }.sortedBy { it.first }
        val caps = candidates.firstOrNull()?.second
        caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }.getOrDefault(true)

    private fun String.toIpPrefix(): IpPrefix = IpPrefix(this)

    private fun readSplitExclusions(): List<String> = runCatching {
        val prefs = service.getSharedPreferences("smart_tunnel_secure", Context.MODE_PRIVATE)
        val raw = prefs.getString("split_exclude_packages", "[]") ?: "[]"
        val array = org.json.JSONArray(raw)
        (0 until array.length()).map { array.optString(it) }.filter { it.isNotBlank() }.distinct()
    }.getOrDefault(emptyList())

    override fun useProcFS(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q

    override fun findConnectionOwner(
        ipProtocol: Int,
        sourceAddress: String,
        sourcePort: Int,
        destinationAddress: String,
        destinationPort: Int
    ): ConnectionOwner {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) error("Android connection-owner lookup requires API 29+")
        val cm = service.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val uid = cm.getConnectionOwnerUid(
            ipProtocol,
            InetSocketAddress(sourceAddress, sourcePort),
            InetSocketAddress(destinationAddress, destinationPort)
        )
        if (uid == Process.INVALID_UID) error("مالک اتصال پیدا نشد")
        val packages = service.packageManager.getPackagesForUid(uid)?.toList().orEmpty()
        return ConnectionOwner().apply {
            userId = uid
            userName = packages.firstOrNull() ?: ""
            setAndroidPackageNames(StringArray(packages.iterator()))
        }
    }

    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        defaultInterfaceListener = listener
        updateDefaultInterface(listener)
        if (networkCallback != null) return
        val cm = service.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) = updateDefaultInterface(listener)
            override fun onLost(network: Network) = updateDefaultInterface(listener)
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) = updateDefaultInterface(listener)
        }
        try {
            cm.registerNetworkCallback(
                NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build(),
                cb
            )
            networkCallback = cb
        } catch (e: Exception) {
            Log.w(TAG, "Cannot monitor underlying networks: ${e.message}")
        }
    }

    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) {
        stopDefaultInterfaceMonitor(listener)
    }

    private fun stopDefaultInterfaceMonitor(listener: InterfaceUpdateListener?) {
        val cb = networkCallback
        networkCallback = null
        if (cb != null) {
            val cm = service.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            runCatching { cm.unregisterNetworkCallback(cb) }
        }
    }

    private fun updateDefaultInterface(listener: InterfaceUpdateListener) {
        try {
            val cm = service.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val candidates = cm.allNetworks.mapNotNull { network ->
                val caps = cm.getNetworkCapabilities(network) ?: return@mapNotNull null
                val props = cm.getLinkProperties(network) ?: return@mapNotNull null
                if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ||
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) return@mapNotNull null
                val javaInterface = runCatching { JavaNetworkInterface.getByName(props.interfaceName) }.getOrNull() ?: return@mapNotNull null
                // Prefer validated uplinks, then Wi-Fi/cellular. Do not blindly prefer a dead or captive Wi-Fi network.
                val priority = (if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) 0 else 10) + when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> 0
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> 1
                    else -> 2
                }
                Triple(priority, javaInterface, caps)
            }.sortedBy { it.first }
            val chosen = candidates.firstOrNull()
            if (chosen == null) {
                listener.updateDefaultInterface("", -1, false, false)
            } else {
                val iface = chosen.second
                val metered = !chosen.third.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
                listener.updateDefaultInterface(iface.name, iface.index, metered, false)
            }
        } catch (e: Exception) {
            Log.w(TAG, "default interface update failed: ${e.message}")
        }
    }

    override fun getInterfaces(): NetworkInterfaceIterator {
        val cm = service.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networks = cm.allNetworks
        val enumeration = JavaNetworkInterface.getNetworkInterfaces()
        val jInterfaces = if (enumeration != null) Collections.list(enumeration) else emptyList()
        val result = mutableListOf<BoxNetworkInterface>()
        for (network in networks) {
            val props = cm.getLinkProperties(network) ?: continue
            val caps = cm.getNetworkCapabilities(network) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
            val javaInterface = jInterfaces.firstOrNull { it.name == props.interfaceName } ?: continue
            val item = BoxNetworkInterface().apply {
                name = props.interfaceName ?: javaInterface.name
                dnsServer = StringArray(props.dnsServers.mapNotNull { it.hostAddress }.iterator())
                dnsSearchDomain = StringArray(props.domains?.split(' ')?.filter { it.isNotBlank() }.orEmpty().iterator())
                gateway = StringArray(props.routes.filter { it.isDefaultRoute }.mapNotNull { it.gateway?.hostAddress }.iterator())
                type = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> Libbox.InterfaceTypeWIFI
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Libbox.InterfaceTypeCellular
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Libbox.InterfaceTypeEthernet
                    else -> Libbox.InterfaceTypeOther
                }
                index = javaInterface.index
                mtu = runCatching { javaInterface.mtu }.getOrDefault(1500)
                addresses = StringArray(javaInterface.interfaceAddresses.map { address ->
                    val ip = if (address.address is Inet6Address) address.address.hostAddress.substringBefore('%') else address.address.hostAddress
                    "$ip/${address.networkPrefixLength}"
                }.iterator())
                flags = (if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) OsConstants.IFF_UP or OsConstants.IFF_RUNNING else 0) or
                    (if (javaInterface.isLoopback) OsConstants.IFF_LOOPBACK else 0) or
                    (if (javaInterface.isPointToPoint) OsConstants.IFF_POINTOPOINT else 0) or
                    (if (javaInterface.supportsMulticast()) OsConstants.IFF_MULTICAST else 0)
                metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
            }
            result.add(item)
        }
        return InterfaceArray(result.iterator())
    }

    override fun underNetworkExtension(): Boolean = false
    override fun includeAllNetworks(): Boolean = false
    override fun readWIFIState(): WIFIState? = null
    override fun localDNSTransport(): LocalDNSTransport? = null
    override fun clearDNSCache() = Unit
    override fun sendNotification(notification: Notification) = Unit
    override fun cancelNotification(identifier: String, typeID: Int) = Unit
    override fun startNeighborMonitor(listener: NeighborUpdateListener?) = Unit
    override fun closeNeighborMonitor(listener: NeighborUpdateListener?) = Unit
    override fun registerMyInterface(name: String?) = Unit
    override fun usePlatformShell(): Boolean = false
    override fun checkPlatformShell() = error("Platform shell is not available")
    override fun openShellSession(user: PlatformUser?, command: String?, environ: StringIterator?, term: String?, rows: Int, cols: Int): ShellSession = error("Platform shell is not available")
    override fun readSystemSSHHostKey(): String = error("SSH host key is not available")
    override fun lookupSFTPServer(): String = error("SFTP is not available")
    override fun tailscaleHostname(): String = "Smart Tunnel"
    override fun usePlatformBridge(): Boolean = false
    override fun createBridge(options: BridgeOptions?): BridgeSession = error("Platform bridge is not available")
    override fun usePlatformAutoRedirect(): Boolean = false
    override fun createAutoRedirect(options: ByteArray?, handler: AutoRedirectHandler?): AutoRedirectSession = error("Platform auto-redirect is not available")
    override fun lookupUser(username: String?): PlatformUser = error("System user lookup is not available")

    // ---------------- CommandServerHandler ----------------

    override fun serviceStop() {
        // CommandServer may stop after a runtime failure. Reflect it in the UI instead of leaving a stale "connected" state.
        val wasRunning = running.getAndSet(false)
        if (wasRunning) {
            val message = "موتور sing-box سرویس تونل را متوقف کرد"
            lastError = message
            SmartTunnelVpnService.lastStatus = "error"
            SmartTunnelVpnService.lastFailure = message
        }
        closeTun()
        stopDefaultInterfaceMonitor(defaultInterfaceListener)
        defaultInterfaceListener = null
    }

    override fun serviceReload() {
        val config = lastConfig ?: return
        try {
            commandServer?.startOrReloadService(config, OverrideOptions())
        } catch (e: Exception) {
            lastError = e.message ?: "Reload failed"
            Log.e(TAG, "sing-box reload failed", e)
        }
    }

    override fun getSystemProxyStatus(): SystemProxyStatus = SystemProxyStatus().apply {
        available = false
        enabled = false
    }

    override fun setSystemProxyEnabled(isEnabled: Boolean) = Unit
    override fun triggerNativeCrash() = Unit
    override fun writeDebugMessage(message: String?) { if (!message.isNullOrBlank()) Log.d(TAG, message) }
    override fun connectSSHAgent(): Int = -1

    private class StringArray(values: Iterator<String>) : StringIterator {
        private val items = values.asSequence().toList()
        private var index = 0
        override fun len(): Int = items.size
        override fun hasNext(): Boolean = index < items.size
        override fun next(): String = items[index++]
    }

    private class InterfaceArray(private val iterator: Iterator<BoxNetworkInterface>) : NetworkInterfaceIterator {
        override fun hasNext(): Boolean = iterator.hasNext()
        override fun next(): BoxNetworkInterface = iterator.next()
    }

    private class NeighborArray(private val iterator: Iterator<NeighborEntry>) : NeighborEntryIterator {
        override fun hasNext(): Boolean = iterator.hasNext()
        override fun next(): NeighborEntry = iterator.next()
    }

    companion object { private const val TAG = "SmartTunnelEngine" }
}
