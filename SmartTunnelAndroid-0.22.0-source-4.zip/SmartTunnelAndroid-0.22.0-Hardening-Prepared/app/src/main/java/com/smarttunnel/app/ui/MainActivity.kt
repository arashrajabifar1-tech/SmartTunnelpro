package com.smarttunnel.app.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.smarttunnel.app.BuildConfig
import com.smarttunnel.app.bridge.SmartTunnelBridge
import com.smarttunnel.app.databinding.ActivityMainBinding
import com.smarttunnel.app.vpn.SmartTunnelVpnService

/**
 * WebView host — کل UI از assets/index.html لود می‌شود.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var bridge: SmartTunnelBridge
    @Volatile private var mainPageReady = false
    private var pendingIncomingIntent: Intent? = null

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                bridge.onVpnPermissionGranted()
            } else {
                bridge.onVpnPermissionDenied()
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        bridge = SmartTunnelBridge(this, binding.webView) { intent ->
            vpnPermissionLauncher.launch(intent)
        }

        val wv = binding.webView
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true // Required for bundled file:///android_asset/index.html
        // Never grant local-file scripts cross-origin access; only bundled UI is loaded here.
        s.allowFileAccessFromFileURLs = false
        s.allowUniversalAccessFromFileURLs = false
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) s.safeBrowsingEnabled = true
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.mediaPlaybackRequiresUserGesture = false
        // برای QR / دوربین در WebView
        s.allowContentAccess = true

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString().orEmpty()
                if (url.startsWith("smarttunnel://")) {
                    bridge.handleDeepLink(url)
                    return true
                }
                // Keep the JavaScript bridge confined to the bundled, trusted UI.
                if (url == "file:///android_asset/index.html") return false
                if (url.startsWith("file:///android_asset/")) return true
                if (url.startsWith("https://") || url.startsWith("http://")) {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, request?.url)) }
                    return true
                }
                return true
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (url?.startsWith("file:///android_asset/index.html") == true) {
                    mainPageReady = true
                    // JS Bridge calls must wait until the bundled UI has finished executing.
                    bridge.notifyNativeReady()
                    val pending = pendingIncomingIntent
                    pendingIncomingIntent = null
                    if (pending != null) dispatchIncomingIntent(pending)
                }
            }
        }
        wv.webChromeClient = WebChromeClient()

        // نام دقیقاً مطابق HTML: window.SmartTunnelNative
        wv.addJavascriptInterface(bridge, "SmartTunnelNative")

        wv.loadUrl("file:///android_asset/index.html")

        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let { handleIncomingIntent(it) }
    }

    private fun handleIncomingIntent(intent: Intent) {
        if (!mainPageReady) {
            // ACTION_SEND/ACTION_VIEW can arrive before WebView finishes loading the offline UI.
            pendingIncomingIntent = Intent(intent)
            return
        }
        dispatchIncomingIntent(intent)
    }

    private fun dispatchIncomingIntent(intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                if (!text.isNullOrBlank()) bridge.deliverSharedText(text)
            }
            Intent.ACTION_VIEW -> intent.dataString?.let { bridge.handleDeepLink(it) }
        }
    }

    /** درخواست مجوز سیستم VPN */
    fun requestVpnPermission() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            vpnPermissionLauncher.launch(prepare)
        } else {
            bridge.onVpnPermissionGranted()
        }
    }

    fun startVpnService(configJson: String) {
        val i = Intent(this, SmartTunnelVpnService::class.java).apply {
            action = SmartTunnelVpnService.ACTION_START
            putExtra(SmartTunnelVpnService.EXTRA_CONFIG, configJson)
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(i)
        } else {
            startService(i)
        }
    }

    fun stopVpnService() {
        val i = Intent(this, SmartTunnelVpnService::class.java).apply {
            action = SmartTunnelVpnService.ACTION_STOP
        }
        startService(i)
    }

    override fun onDestroy() {
        binding.webView.removeJavascriptInterface("SmartTunnelNative")
        binding.webView.destroy()
        super.onDestroy()
    }
}
