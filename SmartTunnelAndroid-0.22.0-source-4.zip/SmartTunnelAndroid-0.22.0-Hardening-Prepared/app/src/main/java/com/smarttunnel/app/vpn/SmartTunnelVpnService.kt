package com.smarttunnel.app.vpn

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.smarttunnel.app.R
import com.smarttunnel.app.SmartTunnelApp
import com.smarttunnel.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * VpnService رسمی اندروید — موتور را نگه می‌دارد و نوتیفیکیشن foreground می‌دهد.
 */
class SmartTunnelVpnService : VpnService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var engine: VpnEngine
    private val commandMutex = Mutex()
    private var commandJob: kotlinx.coroutines.Job? = null

    @Volatile
    var lastError: String? = null
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        engine = VpnEngine(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            // Do not leave a ghost foreground service after process recreation without its config.
            lastStatus = "disconnected"
            lastFailure = null
            stopSelf(startId)
            return START_NOT_STICKY
        }
        when (intent.action) {
            ACTION_START -> {
                val cfg = intent.getStringExtra(EXTRA_CONFIG).orEmpty()
                lastStatus = "connecting"
                lastFailure = null
                lastError = null
                startForeground(NOTIF_ID, buildNotification(getString(R.string.vpn_notification_connecting)))
                commandJob?.cancel()
                commandJob = scope.launch {
                    commandMutex.withLock {
                        if (!currentCoroutineContext().isActive) return@withLock
                        val err = engine.start(cfg)
                        if (!currentCoroutineContext().isActive) {
                            engine.stop()
                            lastStatus = "disconnected"
                            return@withLock
                        }
                        lastError = err
                        if (err != null) {
                            lastStatus = "error"
                            lastFailure = err
                            Log.e(TAG, err)
                            stopForeground(STOP_FOREGROUND_REMOVE)
                            stopSelf(startId)
                        } else {
                            lastStatus = "connected"
                            lastFailure = null
                            startForeground(NOTIF_ID, buildNotification(getString(R.string.vpn_notification_connected)))
                        }
                    }
                }
            }
            ACTION_STOP -> {
                lastStatus = "disconnected"
                lastFailure = null
                commandJob?.cancel()
                commandJob = scope.launch {
                    commandMutex.withLock {
                        stopTunnel()
                        lastStatus = "disconnected"
                        lastFailure = null
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf(startId)
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun stopTunnel() {
        engine.stop()
    }

    fun traffic() = engine.traffic()

    fun isConnected(): Boolean = engine.isRunning()

    private fun buildNotification(content: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, SmartTunnelApp.CHANNEL_VPN)
            .setContentTitle(getString(R.string.vpn_notification_title))
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onRevoke() {
        commandJob?.cancel()
        lastStatus = "disconnected"
        lastFailure = null
        stopTunnel()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        commandJob?.cancel()
        val failed = lastStatus == "error"
        stopTunnel()
        if (!failed) lastStatus = "disconnected"
        scope.cancel()
        instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? {
        return super.onBind(intent)
    }

    companion object {
        private const val TAG = "STVpnService"
        const val ACTION_START = "com.smarttunnel.app.VPN_START"
        const val ACTION_STOP = "com.smarttunnel.app.VPN_STOP"
        const val EXTRA_CONFIG = "config"
        private const val NOTIF_ID = 1001

        @Volatile
        var instance: SmartTunnelVpnService? = null
            private set

        @Volatile var lastStatus: String = "disconnected"
        @Volatile var lastFailure: String? = null
    }
}
