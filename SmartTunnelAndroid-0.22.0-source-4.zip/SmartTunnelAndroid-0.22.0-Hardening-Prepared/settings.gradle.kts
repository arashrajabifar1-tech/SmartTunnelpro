pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
        // libbox AAR اگر از Maven محلی استفاده می‌کنید
        flatDir { dirs("app/libs") }
    }
}
rootProject.name = "SmartTunnel"
include(":app")
