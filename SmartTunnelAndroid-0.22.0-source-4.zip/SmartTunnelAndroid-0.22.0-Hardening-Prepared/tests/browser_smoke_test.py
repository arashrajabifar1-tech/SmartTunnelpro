from pathlib import Path
from playwright.sync_api import sync_playwright
import json, os, shutil
ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'app/src/main/assets/index.html').resolve()
CHROMIUM = os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
errors=[]; downloads=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, **({'executable_path': CHROMIUM} if CHROMIUM else {}), args=['--no-sandbox','--disable-dev-shm-usage','--allow-file-access-from-files'])
    context=browser.new_context(accept_downloads=True)
    page=context.new_page()
    page.set_default_timeout(3000)
    page.add_init_script("""(()=>{const m=new Map(); const ls={getItem:k=>m.has(String(k))?m.get(String(k)):null,setItem:(k,v)=>m.set(String(k),String(v)),removeItem:k=>m.delete(String(k)),clear:()=>m.clear(),key:i=>Array.from(m.keys())[i]??null,get length(){return m.size}};Object.defineProperty(window,'localStorage',{value:ls,configurable:true});})();""")
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: errors.append('console error: '+m.text) if m.type=='error' else None)
    html_text=html.read_text()
    polyfill="Object.defineProperty(window,'localStorage',{configurable:true,value:(()=>{const m=new Map();return {getItem:k=>m.has(String(k))?m.get(String(k)):null,setItem:(k,v)=>m.set(String(k),String(v)),removeItem:k=>m.delete(String(k)),clear:()=>m.clear(),key:i=>Array.from(m.keys())[i]??null,get length(){return m.size}}})()});"
    html_text=html_text.replace('<script>', '<script>'+polyfill+'\n', 1)
    page.set_content(html_text, wait_until='domcontentloaded', timeout=12000)
    page.wait_for_timeout(1500)
    assert 'Smart Tunnel' in page.title(), page.title()
    assert page.locator('#speedBoosterCard').count() == 1, 'Speed Booster card missing'
    assert page.locator('#spSize').count() == 1, 'speed size selector missing'
    assert page.locator('#spFetch').count() == 1, 'community source button missing'
    assert 'تست واقعی' in page.locator('#speedBoosterCard').inner_text() or 'Real speed test' in page.locator('#speedBoosterCard').inner_text()
    page.evaluate("document.querySelectorAll('.stov,.st-overlay,.tour-overlay').forEach(e=>e.remove())")
    # Add a syntactically valid sample profile, using reserved example endpoint values; no network connection is attempted.
    page.locator('[data-tab="profiles"]').first.evaluate('(el)=>el.click()')
    page.locator('#pName').fill('Local test proxy')
    page.locator('#pType').select_option('vless')
    page.locator('#pAddress').fill('vless://123e4567-e89b-42d3-a456-426614174000@example.com:443?security=reality&pbk=AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA&sid=0123456789abcdef&sni=example.com&fp=chrome&type=tcp&flow=xtls-rprx-vision#Test')
    page.locator('#addProfile').click(force=True)
    page.wait_for_timeout(100)
    assert 'Local test proxy' in page.locator('#profilesBox').inner_text(), page.locator('#profilesBox').inner_text()
    # Build the normal config and assert route, DNS bypass and conservative MTU.
    page.locator('[data-tab="config"]').first.evaluate('(el)=>el.click()')
    page.locator('#buildConfig').click(force=True)
    page.wait_for_timeout(100)
    out=page.locator('#configOut').inner_text()
    if out.strip() in ('—','') or 'domain_suffix' not in out:
        raise AssertionError('normal config did not build with Iranian-domain route: '+page.locator('#configCheck').inner_text())
    config=json.loads(out)
    tun=next(x for x in config['inbounds'] if x.get('type')=='tun')
    assert tun.get('mtu')==1400, tun
    assert any('.ir' in x.get('domain_suffix',[]) and x.get('outbound')=='direct' for x in config['route']['rules']), config['route']['rules']
    assert any('.ir' in x.get('domain_suffix',[]) and x.get('server')=='doh' for x in config['dns']['rules']), config['dns']['rules']
    # ShadowTLS parser/schema regression, using example-only test values.
    page.locator('[data-tab="profiles"]').first.evaluate('(el)=>el.click()')
    page.locator('#pName').fill('ShadowTLS v3 example')
    page.locator('#pType').select_option('shadowtls')
    page.locator('#pAddress').fill('shadowtls://sample-secret@example.com:443?sni=www.example.com&version=3#ShadowTLS-Test')
    page.locator('#addProfile').click(force=True)
    page.locator('[data-tab="config"]').first.evaluate('(el)=>el.click()')
    page.locator('#buildConfig').click(force=True)
    shadow_config=json.loads(page.locator('#configOut').inner_text())
    shadow=next(o for o in shadow_config['outbounds'] if o.get('type')=='shadowtls')
    assert shadow['version']==3 and shadow['password']=='sample-secret', shadow
    assert shadow['tls']['enabled'] is True and shadow['tls']['server_name']=='www.example.com', shadow
    page.locator('[data-tab="profiles"]').first.evaluate('(el)=>el.click()')
    page.locator('#pName').fill('ShadowTLS v1 example')
    page.locator('#pType').select_option('shadowtls')
    page.locator('#pAddress').fill('shadowtls://example.com:443?sni=www.example.com&version=1#ShadowTLS-v1')
    page.locator('#addProfile').click(force=True)
    page.locator('[data-tab="config"]').first.evaluate('(el)=>el.click()')
    page.locator('#buildConfig').click(force=True)
    shadow_config=json.loads(page.locator('#configOut').inner_text())
    shadow_v1=next(o for o in shadow_config['outbounds'] if o.get('type')=='shadowtls' and o.get('version')==1)
    assert 'password' not in shadow_v1, shadow_v1
    # Build emergency config with extra Iran domains.
    page.locator('[data-tab="st-emergency"]').evaluate('(el)=>el.click()')
    page.locator('#stEmergencyDomesticDomains').fill('bank.example.com\nportal.example.net')
    page.wait_for_timeout(100)
    page.locator('#stEmergencyBuild').click(force=True)
    page.wait_for_timeout(100)
    emerg=page.locator('#stEmergencyConfig').inner_text()
    if emerg.strip() in ('—',''):
        raise AssertionError('emergency config did not build: '+page.locator('#stEmergencyConfigStatus').inner_text())
    ec=json.loads(emerg)
    suffix_rule=next(x for x in ec['route']['rules'] if '.ir' in x.get('domain_suffix',[]))
    assert '.bank.example.com' in suffix_rule['domain_suffix'], suffix_rule
    assert '.portal.example.net' in suffix_rule['domain_suffix'], suffix_rule
    assert ec['route']['final']=='st-emergency-proxy'
    assert not ec.get('route',{}).get('rule_set'), ec.get('route')
    # Reject invalid user domains; do not build a deceptive config.
    page.locator('#stEmergencyDomesticDomains').fill('https://bad.example/path')
    page.locator('#stEmergencyBuild').click(force=True)
    page.wait_for_timeout(100)
    assert 'نامعتبر' in page.locator('#stEmergencyConfigStatus').inner_text(), page.locator('#stEmergencyConfigStatus').inner_text()
    # Speed Booster controls persist settings; this is UI/config testing only, not a real speed test.
    page.locator('[data-tab="tools"]').first.evaluate('(el)=>el.click()')
    page.locator('#spSize').select_option('5')
    stored=page.evaluate("JSON.parse(localStorage.getItem('smartTunnel.v100.cfg')||'{}')")
    assert stored.get('speedTestSizeMB') == 5, stored
    page.locator('#spSize').select_option('2')
    page.locator('#spDnsProvider').select_option('google')
    stored=page.evaluate("JSON.parse(localStorage.getItem('smartTunnel.v100.cfg')||'{}')")
    assert stored.get('fastDnsProvider') == 'google', stored
    page.locator('#spDnsProvider').select_option('cloudflare')
    page.locator('#spSources').uncheck()
    stored=page.evaluate("JSON.parse(localStorage.getItem('smartTunnel.v100.cfg')||'{}')")
    assert stored.get('boostSources') == 0, stored
    assert page.locator('#spFetch').is_disabled()
    page.locator('#spSources').check()
    # No real native bridge is installed in browser mode.
    assert 'این فایل در مرورگر' in page.locator('#engineNotice').inner_text() or 'فقط رابط' in page.locator('#engineNotice').inner_text()
    dialogs=[]
    page.on('dialog', lambda d: (dialogs.append(d.message), d.accept()))
    page.locator('#spRun').click(force=True)
    page.wait_for_timeout(100)
    assert dialogs and ('APK نصب‌شده' in dialogs[-1] or 'APK' in dialogs[-1]), dialogs
    browser.close()
print('PASS browser: page load and no JS errors')
print('PASS browser: profile add + normal config generation')
print('PASS browser: MTU=1400')
print('PASS browser: .ir routing and DoH DNS rule in normal config')
print('PASS browser: ShadowTLS v3 URI builds expected sing-box outbound')
print('PASS browser: ShadowTLS v1 omits password as required by sing-box schema')
print('PASS browser: emergency config, custom direct domains, no remote rule sets')
print('PASS browser: invalid domain rejected')
print('PAGE_ERRORS=',json.dumps(errors,ensure_ascii=False))

# Test explicit Mock mode in a separate page: simulated connection must never appear as a real VPN.
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, **({'executable_path': CHROMIUM} if CHROMIUM else {}), args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page()
    page.set_default_timeout(3000)
    page.on('pageerror', lambda e: errors.append('mock page: '+str(e)))
    mock_html=html.read_text()
    mock_html=mock_html.replace("if(q.get('mock')!=='1'&&q.get('mock')!=='true')return;", "if(false)return;", 1)
    polyfill="Object.defineProperty(window,'localStorage',{configurable:true,value:(()=>{const m=new Map();return {getItem:k=>m.has(String(k))?m.get(String(k)):null,setItem:(k,v)=>m.set(String(k),String(v)),removeItem:k=>m.delete(String(k)),clear:()=>m.clear(),key:i=>Array.from(m.keys())[i]??null,get length(){return m.size}}})()});"
    mock_html=mock_html.replace('<script>', '<script>'+polyfill+'\n', 1)
    page.set_content(mock_html, wait_until='domcontentloaded', timeout=12000)
    page.wait_for_timeout(400)
    status=page.evaluate("window.SmartTunnelNative.requestVpn('{}')")
    assert status=='OK', status
    page.wait_for_timeout(3300)
    pill=page.locator('#state').inner_text()
    assert 'VPN واقعی وصل نیست' in pill, pill
    exported=page.evaluate("window.SmartTunnelNative.secureExport('{\"secret\":\"sample\"}','a-strong-password-value')")
    assert str(exported).startswith('ERROR:'), exported
    browser.close()
print('PASS browser: Mock mode never reports a real VPN connection')
print('PASS browser: Mock mode refuses fake encrypted backup/export')
print('PASS browser: Speed Booster card and settings persist')
print('PASS browser: public config-source toggle is respected')
print('PASS browser: Browser mode refuses to claim real throughput')
