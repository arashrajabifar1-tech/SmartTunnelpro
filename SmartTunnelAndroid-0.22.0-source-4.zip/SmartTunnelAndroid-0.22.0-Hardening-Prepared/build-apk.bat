@echo off
setlocal
cd /d "%~dp0"
where java >nul 2>nul || (echo ERROR: Install JDK 17 and add java to PATH.& exit /b 2)
where gradle >nul 2>nul || (echo ERROR: Install Gradle 8.7 and add gradle to PATH. Or use the GitHub Actions build workflow.& exit /b 2)
if "%ANDROID_HOME%"=="" if "%ANDROID_SDK_ROOT%"=="" (echo ERROR: Set ANDROID_HOME or ANDROID_SDK_ROOT to the Android SDK folder.& exit /b 2)
gradle --version
if errorlevel 1 exit /b %errorlevel%
gradle --no-daemon clean assembleDebug
if errorlevel 1 exit /b %errorlevel%
if exist "app\build\outputs\apk\debug\app-debug.apk" (
  echo APK created at: %CD%\app\build\outputs\apk\debug\app-debug.apk
  certutil -hashfile "app\build\outputs\apk\debug\app-debug.apk" SHA256
) else (
  echo ERROR: Expected APK was not produced.
  exit /b 3
)
endlocal
