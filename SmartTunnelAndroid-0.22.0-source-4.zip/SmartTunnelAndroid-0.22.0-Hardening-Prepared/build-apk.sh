#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: Java is not installed. Install JDK 17 first." >&2
  exit 2
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: Gradle 8.7 is not installed or is not on PATH." >&2
  echo "Alternative: push this folder to a GitHub repository and run Actions > Build Smart Tunnel APK." >&2
  exit 2
fi
SDK_DIR="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
if [[ -z "$SDK_DIR" || ! -d "$SDK_DIR" ]]; then
  echo "ERROR: Set ANDROID_HOME or ANDROID_SDK_ROOT to an Android SDK directory." >&2
  exit 2
fi
gradle --version
gradle --no-daemon clean assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
if [[ -f "$APK" ]]; then
  echo "APK created: $(pwd)/$APK"
  sha256sum "$APK"
else
  echo "ERROR: Gradle finished without the expected APK." >&2
  exit 3
fi
